# PRIME Presenter Portfolio

A no-key interactive portfolio prototype for PRIME.

## Included

- Animated PRIME guide
- Topic-by-topic presentation mode
- Browser speech synthesis
- Browser voice input where supported
- Portfolio/company Q&A
- Responsive investor-style interface
- No API key required

## Run

Open `index.html` directly, or run a local server:

```bash
python -m http.server 8080
```

Then visit `http://localhost:8080`.

## Next production upgrade

Replace the local keyword answer engine in `app.js` with a server-side PRIME/OpenAI endpoint, add authenticated memory, presentation analytics, downloadable investor materials, and an admin knowledge editor.
