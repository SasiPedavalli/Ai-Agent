const topics = {
  home: {
    title: "PRIME",
    html: `<h1>From raw events to <span>real intelligence.</span></h1><p>A secure, self-evolving intelligence operating system designed to improve every day and power products across industries.</p>`,
    narration: "Welcome to PRIME. PRIME is a self-evolving intelligence operating system. It is designed not merely to answer questions, but to learn from outcomes, improve its own workflows, and power products across industries."
  },
  vision: {
    title: "The vision",
    html: `<h1>Self-evolution is the <span>product moat.</span></h1><p>The winning AI system will not only be large. It will observe real results, find weaknesses, generate better strategies, and promote only verified improvements.</p>`,
    narration: "Our central thesis is simple. The winner will not be the largest chatbot alone. It will be the intelligence system that becomes better the fastest. PRIME turns failures, corrections, latency, cost and user value into measurable improvement signals."
  },
  evolution: {
    title: "Daily evolution",
    html: `<h1>Controlled daily <span>evolution.</span></h1><div class="present-grid"><div>Observe real outcomes</div><div>Generate candidates</div><div>Test in sandbox</div><div>Evaluate and promote</div></div><p>Every change is versioned, evaluated, reversible and protected by policy.</p>`,
    narration: "PRIME evolves through a controlled loop. It observes real outcomes, generates candidate improvements, tests them in isolated sandboxes, evaluates quality and safety, and promotes only winners. Every change remains versioned and reversible."
  },
  products: {
    title: "Products",
    html: `<h1>One mother engine.<br><span>Four products.</span></h1><div class="present-grid"><div><b>Guardian X</b><br>Predict failures</div><div><b>Genome</b><br>Evolving risk DNA</div><div><b>Company Brain</b><br>Living memory</div><div><b>Digital Twin</b><br>Simulate decisions</div></div>`,
    narration: "PRIME is the mother intelligence engine. Guardian X predicts failures. Genome builds evolving risk and behavior signatures. Company Brain creates living organizational memory. Digital Twin simulates decisions before they affect the real world."
  },
  security: {
    title: "Security",
    html: `<h1>Private. Controlled.<br><span>Reversible.</span></h1><div class="present-grid"><div>Private repository</div><div>Sandboxed mutations</div><div>Human approvals</div><div>Automatic rollback</div></div><p>Self-evolution without governance is dangerous, so security is part of the architecture—not an add-on.</p>`,
    narration: "Security is built into PRIME from the beginning. Mutations run in sandboxes. High-impact actions require approval. Audit records are immutable, customer environments are isolated, and regressions trigger rollback."
  },

  examples: {
    title: "Real-world examples",
    html: `<h1>PRIME in the <span>real world.</span></h1><div class="present-grid"><div><b>Guardian X</b><br>Predicts a pipeline failure before an SLA breach.</div><div><b>Genome</b><br>Detects evolving fraud behavior from device and transaction patterns.</div><div><b>Company Brain</b><br>Explains a business problem using evidence across systems.</div><div><b>Digital Twin</b><br>Tests future decisions before they affect operations.</div></div>`,
    narration: "Here is what PRIME looks like in practice. Guardian X can predict a pipeline failure before an SLA breach. Genome can identify a changing fraud pattern. Company Brain can explain why an operational problem happened using evidence across systems. Digital Twin can simulate a decision before it affects the real world."
  },
  architecture: {
    title: "Architecture",
    html: `<h1>Four layers create <span>compound intelligence.</span></h1><div class="present-grid"><div><b>Cognitive Core</b><br>Reason and plan</div><div><b>Evolution Engine</b><br>Improve safely</div><div><b>Memory Fabric</b><br>Remember outcomes</div><div><b>Action Fabric</b><br>Execute in the world</div></div>`,
    narration: "PRIME has four major layers. The cognitive core plans and reasons. The evolution engine creates and tests improvements. The memory fabric preserves knowledge and outcomes. The action fabric connects intelligence to code, data, cloud systems, APIs and business workflows."
  },
  business: {
    title: "Business model",
    html: `<h1>High-value products.<br><span>Platform economics.</span></h1><div class="present-grid"><div><b>SaaS</b><br>Team subscriptions</div><div><b>API</b><br>Usage revenue</div><div><b>Enterprise</b><br>Private deployments</div><div><b>Models</b><br>Domain intelligence</div></div>`,
    narration: "PRIME begins with high-value enterprise products and expands into platform economics. Revenue can come from subscriptions, usage-based APIs, enterprise deployments and specialized domain intelligence."
  },
  funding: {
    title: "Funding",
    html: `<h1>Funding turns Genesis into a <span>defensible company.</span></h1><div class="present-grid"><div>Engineering</div><div>Research</div><div>Infrastructure</div><div>Design partners</div></div><p>Capital is used to build the intelligence core, validate it with customers, secure the platform and create proprietary technical advantages.</p>`,
    narration: "Funding is not for a static chatbot. It builds the evolution engine, product infrastructure, security, research capability, and early customer pilots needed to create a defensible AI company."
  },

  architecture: {
    title: "Architecture",
    html: `<h1>More than a chatbot.<br><span>An intelligence operating system.</span></h1><div class="present-grid"><div>Cognitive core</div><div>Memory fabric</div><div>Action fabric</div><div>Evolution engine</div></div><p>PRIME coordinates reasoning, memory, tools, model routing, governance and continuous evaluation as one platform.</p>`,
    narration: "PRIME is not just a chat interface. Its cognitive core plans and reasons. Its memory fabric preserves useful knowledge. Its action fabric connects to software and enterprise systems. Its evolution engine improves workflows, while governance controls every high-impact action."
  },
  business: {
    title: "Business model",
    html: `<h1>Enterprise products first.<br><span>A platform economy next.</span></h1><div class="present-grid"><div>Subscriptions</div><div>Usage-based platform</div><div>Private deployments</div><div>Developer ecosystem</div></div><p>PRIME can monetize through products, platform usage, private infrastructure and partner-built extensions.</p>`,
    narration: "PRIME begins with high-value enterprise subscriptions. It expands into usage-based platform services, private deployments, and a developer ecosystem where partners create specialized products on top of the PRIME core."
  },
  investment: {
    title: "Investment case",
    html: `<h1>Build the intelligence layer<br><span>industries improve on.</span></h1><div class="present-grid"><div>Large unmet problem</div><div>Strong timing</div><div>Focused entry product</div><div>Multi-industry expansion</div></div><p>Guardian X is the entry point. PRIME is the long-term platform opportunity.</p>`,
    narration: "The investment opportunity is not another chatbot. Enterprises need systems that are measurable, governed and continuously improving. Guardian X provides a focused entry point, while the PRIME core creates expansion potential across finance, healthcare, software and many other industries."
  },
  roadmap: {
    title: "Roadmap",
    html: `<h1>A 24-month path to a <span>serious AI company.</span></h1><div class="present-grid"><div><b>0–3</b><br>Genesis</div><div><b>3–6</b><br>Alpha</div><div><b>6–12</b><br>Beta</div><div><b>12–24</b><br>Scale</div></div><p>We begin with the evolution kernel and Guardian X, then add memory, tools, products, customers and proprietary domain intelligence.</p>`,
    narration: "The first three months establish PRIME Genesis and Guardian X. By six months we target an alpha with memory, tools and controlled users. By twelve months we add the other product foundations. The second year focuses on enterprise scale and proprietary domain intelligence."
  }
};

const knowledge = [

  {keys:["example","use case","real world"], answer:"A Guardian X example: it sees rising Kafka consumer lag, schema drift and warehouse latency, predicts an upcoming SLA breach, explains the likely cause, recommends a controlled response, and learns from the final outcome. Genome, Company Brain and Digital Twin follow the same evidence-and-learning approach in their own domains."},
  {keys:["architecture","how it works","layers"], answer:"PRIME uses four layers: a Cognitive Core for planning and reasoning, an Evolution Engine for safe improvement, a Memory Fabric for persistent knowledge, and an Action Fabric for executing through tools, code, data, cloud systems and APIs."},
  {keys:["investor","pitch"], answer:"The investor thesis is that static AI systems lose value as conditions change. PRIME creates a compounding advantage by learning from real outcomes, improving safely and powering multiple high-value enterprise products from one shared intelligence engine."},

  {keys:["what is prime","prime"], answer:"PRIME is a secure, self-evolving intelligence operating system. It learns from task outcomes, generates improved agent and workflow candidates, tests them safely, and promotes only measurable improvements."},
  {keys:["win","advantage","different","moat"], answer:"PRIME's moat is controlled self-evolution. It combines persistent memory, autonomous execution, domain products, security governance and a daily evaluation loop instead of remaining a static chatbot."},
  {keys:["product","guardian","genome","company brain","digital twin"], answer:"PRIME powers four initial products: Guardian X for predictive resilience, Genome for evolving health and financial risk intelligence, Company Brain for organizational memory, and Digital Twin for future-outcome simulation."},
  {keys:["security","safe","privacy"], answer:"PRIME starts private and security-first. Mutations are sandboxed, every version is auditable and reversible, high-impact actions need approval, secrets stay outside code, and customer environments are isolated."},
  {keys:["roadmap","time","months"], answer:"The roadmap is Genesis in months zero to three, Alpha in months three to six, Beta in months six to twelve, and scale in months twelve to twenty-four."},
  {keys:["money","funding","raise","investment"], answer:"The first funding target should finance the Genesis team, secure infrastructure, model and evaluation costs, Guardian X development, design, legal setup and early customer pilots. The exact raise should be finalized after defining team size and runway."},
  {keys:["business","revenue","make money"], answer:"PRIME can generate revenue through SaaS subscriptions, enterprise licenses, private deployments, platform APIs, premium product modules and eventually specialized PRIME models."},

  {keys:["guardian x work","guardian example","pipeline example"], answer:"Example: Kafka consumer lag begins increasing after a deployment. Guardian X connects telemetry, code changes and dependency history, predicts an SLA breach, identifies the likely deployment cause, and proposes rollback or scaling actions before customers are affected."},
  {keys:["genome work","genome example"], answer:"Example: a transaction combines a new device, unusual location, high value and unfamiliar merchant. Genome evaluates the complete behavioral mutation, compares it with prior patterns, and generates an explainable evolving risk signature."},
  {keys:["company brain work","brain example"], answer:"Example: an executive asks which data pipeline created the most customer-impacting incidents. Company Brain connects GitHub changes, Jira issues, Slack decisions, telemetry and incident reports to produce an evidence-linked answer."},
  {keys:["digital twin work","twin example"], answer:"Example: before deploying a major pipeline, Digital Twin simulates traffic, cost, downstream failures and recovery behavior across several future scenarios, helping the company choose the safest strategy."},
  {keys:["architecture","how does prime work"], answer:"PRIME combines a cognitive core, memory fabric, action fabric, model fabric, governance layer and evolution engine. Together they allow it to reason, remember, act, evaluate and improve safely."},
  {keys:["invest","investment","why should someone invest"], answer:"PRIME addresses a major enterprise gap: companies are adopting AI agents but lack a universal system for memory, governance, evaluation and continuous improvement. Guardian X provides a focused first product, while the PRIME core creates expansion across industries."},
  {keys:["founder","sasi"], answer:"Sasi is building PRIME from a strong data engineering and cloud background, with experience across streaming, pipelines, Databricks, Snowflake, AWS, Azure, observability and regulated systems."}
];

const $ = s => document.querySelector(s);
const guide = $("#guide"), messages = $("#messages"), input = $("#question");
function openGuide(){ guide.classList.add("open"); input.focus(); }
function closeGuide(){ guide.classList.remove("open"); }
["#askOpen","#askOpen2","#floatingBot"].forEach(id => $(id)?.addEventListener("click",openGuide));
$("#closeGuide").addEventListener("click",closeGuide);
document.querySelectorAll("[data-jump]").forEach(b=>b.onclick=()=>document.getElementById(b.dataset.jump)?.scrollIntoView());
function addMessage(text,type){const d=document.createElement("div");d.className=`message ${type}`;d.textContent=text;messages.appendChild(d);messages.scrollTop=messages.scrollHeight;}
function answer(q){
  const x=q.toLowerCase();
  const hit=knowledge.find(k=>k.keys.some(key=>x.includes(key)));
  return hit?.answer || "I can explain PRIME's vision, evolution engine, products, security, roadmap, business model, funding plan, or founder background. Ask about one of those topics.";
}
function speak(text){
  if(!$("#speakAnswers").checked || !("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text);
  const voices=speechSynthesis.getVoices();
  const preferred=voices.find(v=>/Daniel|Samantha|Google UK English Male|Microsoft Aria|Microsoft Guy/i.test(v.name)) || voices.find(v=>v.lang.startsWith("en"));
  if(preferred)u.voice=preferred;
  u.rate=.94;u.pitch=.95;u.volume=1;speechSynthesis.speak(u);
}
function submit(q){
  q=(q||input.value).trim(); if(!q)return;
  addMessage(q,"user"); input.value="";
  setTimeout(()=>{const a=answer(q);addMessage(a,"bot");speak(a)},300);
}
$("#sendBtn").onclick=()=>submit(); input.addEventListener("keydown",e=>{if(e.key==="Enter")submit()});
document.querySelectorAll("[data-question]").forEach(b=>b.onclick=()=>submit(b.dataset.question));
$("#stopSpeech").onclick=()=>speechSynthesis.cancel();

const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;
if(Recognition){
  const rec=new Recognition();rec.lang="en-US";rec.interimResults=false;
  rec.onstart=()=>$("#voiceBtn").classList.add("listening");
  rec.onend=()=>$("#voiceBtn").classList.remove("listening");
  rec.onresult=e=>{input.value=e.results[0][0].transcript;submit()};
  $("#voiceBtn").onclick=()=>rec.start();
}else{$("#voiceBtn").onclick=()=>addMessage("Voice input is not supported in this browser. Spoken answers still work.","bot")}

const order=["home","vision","evolution","products","examples","architecture","security","business","funding","roadmap"];
let current=0, paused=false;
function renderSlide(){
  const t=topics[order[current]];
  $("#slideCount").textContent=`${current+1} / ${order.length}`;
  $("#slideTitle").textContent=t.title;
  $("#presentContent").innerHTML=t.html;
  $("#presentNarration").textContent=t.narration;
  if(!paused){$("#speakAnswers").checked=true;speak(t.narration)}
}
function startPresentation(){current=0;paused=false;$("#presenter").classList.remove("hidden");renderSlide()}
$("#presentBtn").onclick=startPresentation;$("#heroPresent").onclick=startPresentation;
$("#exitPresent").onclick=()=>{speechSynthesis.cancel();$("#presenter").classList.add("hidden")};
$("#nextSlide").onclick=()=>{current=(current+1)%order.length;renderSlide()};
$("#prevSlide").onclick=()=>{current=(current-1+order.length)%order.length;renderSlide()};
$("#pauseVoice").onclick=()=>{if(speechSynthesis.speaking&&!speechSynthesis.paused){speechSynthesis.pause();paused=true;$("#pauseVoice").textContent="Resume voice"}else{speechSynthesis.resume();paused=false;$("#pauseVoice").textContent="Pause voice"}};
document.addEventListener("keydown",e=>{if($("#presenter").classList.contains("hidden"))return;if(e.key==="ArrowRight")$("#nextSlide").click();if(e.key==="ArrowLeft")$("#prevSlide").click();if(e.key==="Escape")$("#exitPresent").click()});

const observed=document.querySelectorAll(".topic");
const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.animate([{opacity:.45,transform:"translateY(25px)"},{opacity:1,transform:"none"}],{duration:650,easing:"ease-out"})}),{threshold:.2});
observed.forEach(x=>io.observe(x));

const demos = {
  guardian: {
    title: "Guardian X — Pipeline Failure Prediction",
    steps: [
      "1. Kafka consumer lag rises from 4 seconds to 38 seconds.",
      "2. Guardian X correlates the change with a deployment made 17 minutes earlier.",
      "3. Dependency analysis predicts the downstream warehouse SLA will fail in 26 minutes.",
      "4. PRIME generates three response strategies and evaluates their risk.",
      "5. Recommended action: temporarily scale consumers and prepare rollback approval."
    ]
  },
  genome: {
    title: "Genome — Evolving Fraud Signature",
    steps: [
      "1. A customer uses a new device from a new location.",
      "2. The transaction value is six times higher than the customer's normal range.",
      "3. Genome compares device, temporal, merchant, network and behavioral signals together.",
      "4. The combined mutation receives an explainable risk score.",
      "5. PRIME later learns from the investigation outcome and updates the signature."
    ]
  },
  brain: {
    title: "Company Brain — Evidence-Linked Decision Memory",
    steps: [
      "1. A leader asks which pipeline caused the most customer-impacting incidents.",
      "2. Company Brain searches incidents, code changes, Jira issues, Slack discussions and metrics.",
      "3. It builds a timeline linking technical changes to operational outcomes.",
      "4. Contradictory evidence is highlighted instead of hidden.",
      "5. The answer includes sources, confidence and recommended follow-up actions."
    ]
  },
  twin: {
    title: "Digital Twin — Deployment Simulation",
    steps: [
      "1. A new pipeline design is loaded into the simulation.",
      "2. Digital Twin generates normal, high-traffic and partial-failure scenarios.",
      "3. It estimates cost, latency, downstream impact and recovery time.",
      "4. PRIME compares the predicted outcomes with organizational risk policy.",
      "5. The safest deployment plan is recommended before production changes occur."
    ]
  }
};

function showDemo(name){
  const d=demos[name]; if(!d)return;
  const wrap=document.createElement("div");
  wrap.className="demo-modal";
  wrap.innerHTML=`<div class="demo-card"><h2>${d.title}</h2>${d.steps.map(s=>`<div class="demo-step">${s}</div>`).join("")}<button>Close example</button></div>`;
  document.body.appendChild(wrap);
  speak(`${d.title}. ${d.steps.join(" ")}`);
  wrap.querySelector("button").onclick=()=>{speechSynthesis.cancel();wrap.remove()};
  wrap.onclick=e=>{if(e.target===wrap){speechSynthesis.cancel();wrap.remove()}};
}
document.querySelectorAll("[data-demo]").forEach(b=>b.addEventListener("click",()=>showDemo(b.dataset.demo)));
